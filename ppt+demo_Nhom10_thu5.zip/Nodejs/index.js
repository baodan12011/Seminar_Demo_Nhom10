const express = require('express');
var bodyParser = require('body-parser');
const cors = require('cors');
var app = express();

app.use(cors({
    methods: ["GET, POST, PATCH, PUT, DELETE, OPTIONS"]
}));

const auth = require('./middleware/auth');
app.use(auth);
// app.use(function(req, res, next) {
//     res.header("Access-Control-Allow-Origin", "*");
//     res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
//     res.header("Access-Control-Allow-Methods", "GET, POST, PATCH, PUT, DELETE, OPTIONS");
//     // if (req.url == '/Users/login')
//     //     next();
//     // else
//     //     auth(req, res, next);
//     next();
// });


app.use('/img', express.static(__dirname + '/img'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const customerTypeCtrl = require('./controllers/customer_types')
app.use('/CustomerTypes', customerTypeCtrl);

const customerCtrl = require('./controllers/customers')
app.use('/Customers', customerCtrl);

const userCtrl = require('./controllers/users')
app.use('/Users', userCtrl);
const { CustomerType, Customer, User } = require('./models/db')

// app.post('/login', (req, res) => {
//     console.log(req.body);
//     console.log(req.query);
//     res.send(req.body);
// });


var sever = app.listen(8081, () => { //server chay tren port 8081
    const host = sever.address().address;
    const port = sever.address().port;
    console.log('Server running at http://%s:%s', host, port);

});