const Sequelize = require('sequelize');
const UserModel = require('./user')
const CustomerTypeModel = require('./customer_type')
const CustomerModel = require('./customer') //bao nhiêu model bấy nhiêu dòng

const sequelize = new Sequelize('codefirst', 'sa', '12345', { // sử dụng cho bản exp, bản full không cần
    dialect: 'mssql',
    host: 'localhost',
    dialectOptions: {
        "options": {
            "instanceName": "SQLEXPRESS",
        }
    },
    pool: { max: 20, min: 0, acquire: 30000, idle: 10000 },
    logging: true
});



const User = UserModel(sequelize, Sequelize)
const CustomerType = CustomerTypeModel(sequelize, Sequelize)
const Customer = CustomerModel(sequelize, Sequelize)


Customer.belongsTo(CustomerType, { foreignKey: 'CUT_ID', as: 'customerType' });
CustomerType.hasMany(Customer, { foreignKey: 'CUT_ID', as: 'customers' });

// sequelize.sync({ force: true }).then(() => { //run once
//     console.log('Database created !!!!!')
// });

module.exports = {
    User,
    CustomerType,
    Customer
}