const express = require('express');
const { CustomerType } = require('./../models/db')
const { ErrorResult, Result, PagingResult } = require('./../utils/base_response')
const router = express.Router();
const sequelize = require('sequelize');
const Op = sequelize.Op;

router.use((req, res, next) => {
    // authorize here
    next();
});

// fill customer api
router.get('/', (req, res) => {
    let page = 0;
    if (req.query.p) page = parseInt(req.query.p);
    let pageSize = 20;
    if (req.query.s) pageSize = parseInt(req.query.s);
    let queryString = '';
    if (req.query.q) queryString = '%' + decodeURIComponent(req.query.q) + '%';
    let sortColumn = 'name';
    let sortDirection = 'ASC'
    if (req.query.so) {
        const sortStr = decodeURIComponent(req.query.so).split(' ');
        sortColumn = sortStr[0];
        if (sortStr.length == 2) sortDirection = sortStr[1];
    }

    const offset = (page) * pageSize;
    if (queryString.length == 0) {
        CustomerType.count().then(numRow => {
            const totalRows = numRow;
            const totalPages = Math.ceil(totalRows / pageSize);
            CustomerType.findAll({
                order: [
                    [sortColumn, sortDirection]
                ],
                offset: offset,
                limit: pageSize,

            }).then(customertypes => {
                return res.json(PagingResult(customertypes, {
                    pageNumber: page,
                    pageSize: pageSize,
                    totalRows: totalRows,
                    totalPages: totalPages,
                }))
            });
        });
    } else { // search
        // conditions
        const whereClause = {
            [Op.or]: [{
                    name: {
                        [Op.like]: queryString
                    }
                },
                {
                    commisson: {
                        [Op.like]: queryString
                    }
                },

            ]
        };
        CustomerType.count({ where: whereClause }).then(numRow => {
            const totalRows = numRow;
            const totalPages = Math.ceil(totalRows / pageSize);
            CustomerType.findAll({
                where: whereClause,
                offset: offset,
                limit: pageSize,

            }).then(customertypes => {
                return res.json(PagingResult(customertypes, {
                    pageNumber: page,
                    pageSize: pageSize,
                    totalRows: totalRows,
                    totalPages: totalPages,
                }))
            });
        });
    }
});





// router.get('/', (req, res) => {
//     CustomerType.findAll().then(type => {
//         res.json(Result(type))
//     });
// });
router.get('/:id', (req, res) => { //d+ là những con số, bắt buộc
    CustomerType.findByPk(req.params.id).then(type => {
        if (type != null) {
            res.json(Result(type));
        } else {
            res.status(404).json(ErrorResult(404, 'Not Found !!!'));
        }
    });
});

router.post('/', (req, res) => { //create 
    //validate data here
    CustomerType.create(req.body).then(type => {
        res.json(Result(type));
    }).catch(err => {
        return res.status(400).send(ErrorResult(400, err.errors));
    });
});

router.put('/:id', (req, res) => { //updating
    //validate data here
    CustomerType.findByPk(req.params.id).then(type => {
        if (type != null) {
            type.update({
                name: req.body.name,
                commisson: req.body.commisson
            }).then(type => {
                res.json(Result(type));
            }).catch(err => {
                return res.status(400).send(ErrorResult(400, err.errors));
            });
        } else {
            res.status(404).send(ErrorResult(404, 'Not Found!!'));
        }
    });
});

router.delete('/:id', (req, res) => {
    CustomerType.destroy({
        where: {
            id: req.params.id
        }
    }).then(type => {
        res.json(Result(type));
    }).catch(err => {
        return res.status(500).send(ErrorResult(500, err.errors));
    });
});


module.exports = router;