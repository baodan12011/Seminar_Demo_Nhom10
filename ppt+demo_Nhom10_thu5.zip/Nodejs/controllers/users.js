const express = require('express');
const jwt = require('jsonwebtoken');
const helper = require('../utils/helper');
const crypt = require('../utils/helper');
const { User } = require('./../models/db');
const { ErrorResult, Result } = require('./../utils/base_response');
const router = express.Router();
router.use((req, res, next) => {
    next();
});

router.post('/', (req, res) => {
    req.body.password = crypt.hash(req.body.password);
    User.create(req.body).then(type => {
        res.json(Result(type));
    }).catch(err => {
        return res.status(400).send(ErrorResult(400, err.errors));
    });
});


router.post('/login', (req, res) => {
    User.findOne({
        where: {
            account: req.body.account,
            password: crypt.hash(req.body.password)
        }
    }).then(aUser => {
        if (aUser != null) {
            const token = jwt.sign({ userId: aUser.id, account: aUser.account },
                helper.appKey, { expiresIn: '4h' });
            return res.json(Result({
                id: aUser.id,
                account: aUser.account,
                fullname: aUser.fullname,
                token: token
            }));
        } else {
            res.status(200).send(ErrorResult(401, 'Invalid username or password'));
        }
    });
});
module.exports = router;